# This script fetches vehicle models via a provided API using custom headers to bypass 403 errors.
# It then outputs the results to "output.csv" with columns "brand" and "model".
# Before saving, it removes any commas from the brand, model label, and option name to prevent CSV conflicts.

import requests, csv

# Mapping of brands to their corresponding maker IDs
brands = {
    "VW": 121, "BMW": 16, "MERCEDES-BENZ": 74, "AUDI": 5, "OPEL": 84,
    "FORD": 36, "RENAULT": 93, "SKODA": 106, "FIAT": 35, "PEUGEOT": 88
}

base_url = "https://www.autodoc.parts/ajax/selector/vehicle"
# Custom headers to bypass the 403 forbidden error
headers = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Safari/537.36",
    "Referer": "https://www.autodoc.parts/"
}

with open("output.csv", "w", newline="", encoding="utf-8") as csvfile:
    writer = csv.writer(csvfile)
    writer.writerow(["brand", "model"])
    for brand, maker_id in brands.items():
        url = f"{base_url}?maker={maker_id}&action=models"
        res = requests.get(url, headers=headers)
        if res.status_code != 200:
            print(f"Error fetching data for {brand} ({url}): {res.status_code}")
            continue
        data = res.json()
        for model in data.get("models", []):
            label = model.get("label", "").strip().replace(",", "")
            for option in model.get("options", []):
                opt_name = option.get("name", "").strip().replace(",", "")
                # Ensure the brand string has no commas
                cleaned_brand = brand.replace(",", "")
                writer.writerow([cleaned_brand, f"{label} | {opt_name}"])
print("CSV file generated successfully.")
